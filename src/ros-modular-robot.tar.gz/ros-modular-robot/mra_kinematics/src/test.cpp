/*************************************************************************
	> File Name: main.c
	> Author: 
	> Mail: 
	> Created Time: Fri 15 Dec 2017 11:04:19 AM CST
 ************************************************************************/

#include <stdio.h>
#include "mra_kinematics/mra_kin.h"

int main(int argc, char **argv)
{
	double T[4][4] = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
    double Jnt[7] = {0,0,0,0,0,0,0};
	double sols[8][7];
    double end_s[6];
//	double Wght[7] = {7,6,5,4,3,2,1};

    for(int i = 0; i < 3; i++){
        printf("输入位移参数:");
        scanf("%lf", &T[3][i]);
    }

    mra_kinematics::inverse(T, Jnt, (double *)sols);

    printf("以下为解:\n");
    for(int i = 0; i < 8; i++){
		for(int j = 0; j < 7; j++)
        	printf("%5.2f ", sols[i][j]);
    	printf("\n");

	}
//	forward();
//    printf("以下为根据逆解回算的末端位置:\n");
//    for(int i = 0; i < 6; i++)
//        printf("%8lf ", end_s[i]);
//    printf("\n");

    return 0;
}
