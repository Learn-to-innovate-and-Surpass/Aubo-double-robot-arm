#ifndef MRHW_H
#define MRHW_H

#include <thread>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/force_torque_sensor_interface.h>
#include <hardware_interface/robot_hw.h>
#include <controller_manager/controller_manager.h>
#include <boost/scoped_ptr.hpp>
#include <ros/ros.h>
#include <math.h>
#include <mrapi.h>

namespace ros_control_mr {
class mrHW : public hardware_interface::RobotHW
{
public:
  double loop_hz_;

  /**
   * \brief Constructor
   * \param nh - Node handle for topics.
   */
  mrHW(ros::NodeHandle& nh);
  ~mrHW();

  /// \brief Initialize the hardware interface
  virtual void init();

  /// \brief Read the state from the robot hardware.
  virtual void read(const ros::Time& time, const ros::Duration& period);

  /// \brief write the command to the robot hardware.
  virtual void write(const ros::Time& time, const ros::Duration& period);

  bool prepareSwitch(
      const std::list<hardware_interface::ControllerInfo> &start_list,
      const std::list<hardware_interface::ControllerInfo> &stop_list) const;
  void doSwitch(const std::list<hardware_interface::ControllerInfo>&start_list,
      const std::list<hardware_interface::ControllerInfo>&stop_list);
  void update();

protected:
  void setSpeedMode();
  void setPositionMode();


  // Startup and shutdown of the internal node inside a roscpp program
  ros::NodeHandle nh_;

  // Interfaces
  hardware_interface::JointStateInterface joint_state_interface_;
//  hardware_interface::ForceTorqueSensorInterface force_torque_interface_;
  hardware_interface::PositionJointInterface position_joint_interface_;
  hardware_interface::VelocityJointInterface velocity_joint_interface_;
  hardware_interface::EffortJointInterface effort_joint_interface_;

  bool velocity_interface_running_;
  bool position_interface_running_;
  // Shared memory
  std::vector<std::string> joint_names_;
  std::vector<double> joint_position_;
  std::vector<double> joint_velocity_;
  std::vector<double> joint_effort_;
  std::vector<double> joint_position_command_;
  std::vector<double> joint_velocity_command_;
  std::vector<double> joint_effort_command_;
  std::size_t num_joints_;

  boost::shared_ptr<controller_manager::ControllerManager> controller_manager_;
  std::thread* ros_control_thread_;
  std::vector<JOINT_HANDLE> hJoint_;
  std::vector<int> jointID_;
  std::size_t num_devices_;

}; // end of class
} // end of namespace

#endif // MRHW_H
