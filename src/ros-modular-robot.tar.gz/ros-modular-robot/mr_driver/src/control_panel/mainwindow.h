#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ros/ros.h"
#include <mr_msgs/JointCommand.h>
#include <mr_msgs/GripperCommand.h>
#include <sensor_msgs/JointState.h>
#include <std_msgs/Float32MultiArray.h>
#include <thread>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(ros::NodeHandle nh, QWidget *parent = 0);
    ~MainWindow();

private slots:
    void onPbnLeftPressed();
    void onPbnRightPressed();
    void onPbnReleased();

    void on_pbn_gripperOpen_clicked();

    void on_pbn_gripperClose_clicked();

private:
    Ui::MainWindow *ui;
    ros::NodeHandle nh_;
    ros::Publisher command_pub;
    ros::Publisher gcommand_pub;
    ros::Subscriber sub;
    double m_speed;
    void rosThread();
    void chatterCallback(const sensor_msgs::JointStateConstPtr &msg);
};

#endif // MAINWINDOW_H
