#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>
#include <vector>

MainWindow::MainWindow(ros::NodeHandle nh, QWidget *parent) :
    QMainWindow(parent),
    nh_(nh),
    ui(new Ui::MainWindow),
    m_speed(10.0)
{
    ui->setupUi(this);

    std::thread(boost::bind(&MainWindow::rosThread,this)).detach();

    connect(ui->pbn_joint1Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint2Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint3Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint4Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint5Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint6Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));
    connect(ui->pbn_joint7Left, SIGNAL(pressed()), this, SLOT(onPbnLeftPressed()));

    connect(ui->pbn_joint1Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint2Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint3Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint4Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint5Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint6Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));
    connect(ui->pbn_joint7Right, SIGNAL(pressed()), this, SLOT(onPbnRightPressed()));

    connect(ui->pbn_joint1Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint2Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint3Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint4Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint5Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint6Left, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint7Left, SIGNAL(released()), this, SLOT(onPbnReleased()));

    connect(ui->pbn_joint1Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint2Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint3Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint4Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint5Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint6Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
    connect(ui->pbn_joint7Right, SIGNAL(released()), this, SLOT(onPbnReleased()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onPbnLeftPressed()
{
  mr_msgs::JointCommand joint_command;
  joint_command.command = mr_msgs::JointCommand::SPEED_CMD;
  ros::param::get("/hardware_interface/joints", joint_command.names);
  joint_command.cmdspd.assign(7, 0.);

  if (ui->pbn_joint1Left->isDown())
    joint_command.cmdspd[0] = -m_speed;
  if (ui->pbn_joint2Left->isDown())
    joint_command.cmdspd[1] = -m_speed;
  if (ui->pbn_joint3Left->isDown())
    joint_command.cmdspd[2] = -m_speed;
  if (ui->pbn_joint4Left->isDown())
    joint_command.cmdspd[3] = -m_speed;
  if (ui->pbn_joint5Left->isDown())
    joint_command.cmdspd[4] = -m_speed;
  if (ui->pbn_joint6Left->isDown())
    joint_command.cmdspd[5] = -m_speed;
  if (ui->pbn_joint7Left->isDown())
    joint_command.cmdspd[6] = -m_speed;
  command_pub.publish(joint_command);
  ROS_INFO("joint command send");
}

void MainWindow::onPbnRightPressed()
{
  mr_msgs::JointCommand joint_command;
  joint_command.command = mr_msgs::JointCommand::SPEED_CMD;
  ros::param::get("/hardware_interface/joints", joint_command.names);
  joint_command.cmdspd.assign(joint_command.names.size(), 0.);

  if (ui->pbn_joint1Right->isDown())
    joint_command.cmdspd[0] = m_speed;
  if (ui->pbn_joint2Right->isDown())
    joint_command.cmdspd[1] = m_speed;
  if (ui->pbn_joint3Right->isDown())
    joint_command.cmdspd[2] = m_speed;
  if (ui->pbn_joint4Right->isDown())
    joint_command.cmdspd[3] = m_speed;
  if (ui->pbn_joint5Right->isDown())
    joint_command.cmdspd[4] = m_speed;
  if (ui->pbn_joint6Right->isDown())
    joint_command.cmdspd[5] = m_speed;
  if (ui->pbn_joint7Right->isDown())
    joint_command.cmdspd[6] = m_speed;
  command_pub.publish(joint_command);
  ROS_INFO("joint command send");
}

void MainWindow::onPbnReleased()
{
  mr_msgs::JointCommand joint_command;
  joint_command.command = mr_msgs::JointCommand::SPEED_CMD;
  ros::param::get("/hardware_interface/joints", joint_command.names);
  joint_command.cmdspd.assign(joint_command.names.size(), 0.);

  command_pub.publish(joint_command);
  ROS_INFO("joint command send");
}

void MainWindow::rosThread()
{
  command_pub = nh_.advertise<mr_msgs::JointCommand> ("/mra7a/joint_cmd", 1000);
  gcommand_pub = nh_.advertise<mr_msgs::GripperCommand> ("/mra7a/gripper_cmd", 1000);
  sub = nh_.subscribe("/mra_joint_states", 1, &MainWindow::chatterCallback, this);
  ros::spin();
}

void MainWindow::chatterCallback(const sensor_msgs::JointStateConstPtr &msg)
{
    std::vector<double> joints(7,0.);
    for(int i=0; i < 7; i++) {
        joints[i] = msg->position[i];
    }
    ui->lb_joint1->setText(QString::number(joints[0]*180.0/M_PI, 'f', 6));
    ui->lb_joint2->setText(QString::number(joints[1]*180.0/M_PI, 'f', 6));
    ui->lb_joint3->setText(QString::number(joints[2]*180.0/M_PI, 'f', 6));
    ui->lb_joint4->setText(QString::number(joints[3]*180.0/M_PI, 'f', 6));
    ui->lb_joint5->setText(QString::number(joints[4]*180.0/M_PI, 'f', 6));
    ui->lb_joint6->setText(QString::number(joints[5]*180.0/M_PI, 'f', 6));
    ui->lb_joint7->setText(QString::number(joints[6]*180.0/M_PI, 'f', 6));
}


void MainWindow::on_pbn_gripperOpen_clicked()
{
  std::vector<std::string> names;
  mr_msgs::GripperCommand gripper_command;
  ros::param::get("/hardware_interface/grippers", names);
  gripper_command.name = names[0];
  gripper_command.positionL = 500;
  gripper_command.positionR = 500;
  gcommand_pub.publish(gripper_command);
}

void MainWindow::on_pbn_gripperClose_clicked()
{
  std::vector<std::string> names;
  mr_msgs::GripperCommand gripper_command;
  ros::param::get("/hardware_interface/grippers", names);
  gripper_command.name = names[0];
  gripper_command.positionL = 0;
  gripper_command.positionR = 0;
  gcommand_pub.publish(gripper_command);
}
