#include <QApplication>
#include "mainwindow.h"
#include <thread>

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "control_panel");
    ros::NodeHandle nh;

    QApplication a(argc, argv);
    MainWindow w(nh);
    w.show();


    return a.exec();
}
