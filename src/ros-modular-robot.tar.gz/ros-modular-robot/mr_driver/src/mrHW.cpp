/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2015, University of Colorado, Boulder
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Univ of CO, Boulder nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************

 Author: Dave Coleman
 */

#include <mr_driver/mrHW.h>
#define pi 3.141592653589793238462643383279502884197169399

namespace ros_control_mr {

mrHW::mrHW(ros::NodeHandle& nh) :
    nh_(nh), loop_hz_(100) {
  // Initialize shared memory and interfaces here
  this->init(); // this implementation loads from rosparam

  ROS_INFO_NAMED("mr_hardware_interface", "Loaded mr_hardware_interface.");
}

mrHW::~mrHW()
{
  for (std::size_t i = 0; i < num_devices_; ++i) {
    stopMaster(MASTER(i));
    joinMaster(MASTER(i));
  }
}

void mrHW::init() {
  std::string busname;
  int buf_int;
  char device_key[256];
  ROS_INFO_STREAM_NAMED("mr_hardware_interface",
      "Reading rosparams from namespace: " << nh_.getNamespace());
  if (nh_.getParam("/hardware_interface/peak_can_device/num", buf_int)) {
    ROS_INFO("Got param peak_can_device/num: %d", buf_int);
  }
  else
  {
    ROS_ERROR("Failed to get param '/hardware_interface/peak_can_device/num'");
  }
  nh_.getParam("/hardware_control_loop/loop_hz", loop_hz_);
  num_devices_ = buf_int;
  if (num_devices_ == 0) {
    ROS_ERROR("No peak can device configured");
    exit(-2);
  }
  // start masters(Peak CAN devices)
  for (std::size_t i = 0; i < num_devices_; ++i) {
    std::sprintf(device_key, "/hardware_interface/peak_can_device/device%d", (int)i);
    nh_.getParam(device_key, busname);
    if (busname.c_str() == NULL) {
      ROS_ERROR("Peak can device name not specified");
      exit(-2);
    }
    startMaster(busname.c_str(), MASTER(i));
  }

  // Get joint names
  nh_.getParam("/hardware_interface/joints", joint_names_);
  if (joint_names_.size() == 0) {
    ROS_FATAL_STREAM_NAMED("mr_hardware_interface",
        "No joints found on parameter server for controller, did you load the proper yaml file?" << " Namespace: " << nh_.getNamespace());
    exit(-1);
  }
  nh_.getParam("/hardware_interface/jointID", jointID_);
  num_joints_ = joint_names_.size();
  if (num_joints_ != jointID_.size()) {
    ROS_ERROR("joint names doesn't match joint IDs");
    exit(-2);
  }

  // Resize vectors
  joint_position_.resize(num_joints_);
  joint_velocity_.resize(num_joints_);
  joint_effort_.resize(num_joints_);
  joint_position_command_.resize(num_joints_);
  joint_velocity_command_.resize(num_joints_);
  joint_effort_command_.resize(num_joints_);

  hJoint_.resize(num_joints_);

  // Initialize controller
  for (std::size_t i = 0; i < num_joints_; ++i) {
    int masterId;
    std::vector<std::string> map;
    ROS_INFO_STREAM_NAMED("mr_hardware_interface",
        "Loading joint name: " << joint_names_[i]);
    nh_.getParam("/hardware_interface/jointDevice", map);
    std::sscanf(map.at(i).c_str(), "device%d", &masterId);
    ROS_INFO_STREAM_NAMED("mr_hardware_interface",
        "masterId: " << masterId << " deviceName:" << map.at(i));
    hJoint_[i] = jointUp(jointID_[i], MASTER(masterId));

    // Create joint state interface
    joint_state_interface_.registerHandle(
        hardware_interface::JointStateHandle(joint_names_[i],
            &joint_position_[i], &joint_velocity_[i],
            &joint_effort_[i]));

    // Create position joint interface
    position_joint_interface_.registerHandle(
        hardware_interface::JointHandle(
            joint_state_interface_.getHandle(joint_names_[i]),
            &joint_position_command_[i]));

    // Create velocity joint interface
    velocity_joint_interface_.registerHandle(
        hardware_interface::JointHandle(
            joint_state_interface_.getHandle(joint_names_[i]),
            &joint_velocity_command_[i]));
    // Create velocity joint interface
    effort_joint_interface_.registerHandle(
        hardware_interface::JointHandle(
            joint_state_interface_.getHandle(joint_names_[i]),
            &joint_effort_command_[i]));
  }

  registerInterface(&joint_state_interface_); // From RobotHW base class.
  registerInterface(&position_joint_interface_); // From RobotHW base class.
  registerInterface(&velocity_joint_interface_); // From RobotHW base class.
  registerInterface(&effort_joint_interface_); // From RobotHW base class.
  velocity_interface_running_ = false;
  position_interface_running_ = false;

  // Create the controller manager
  ROS_DEBUG_STREAM_NAMED("hardware_interface","Loading controller_manager");
  controller_manager_.reset(new controller_manager::ControllerManager(this, nh_));

  ros_control_thread_ = new std::thread(&mrHW::update, this);
  ROS_DEBUG("The control thread for this driver has been started");

}

void mrHW::read(const ros::Time& time, const ros::Duration& period) {
  float pos, vel, curr;
  for (std::size_t i = 0; i < num_joints_; ++i) {
    jointPoll(hJoint_[i], &pos, &vel, &curr);
    joint_position_[i] = pos*pi/180.;
    joint_velocity_[i] = vel*pi/180.;
    joint_effort_[i] = curr;
  }
}

void mrHW::write(const ros::Time& time, const ros::Duration& period) {
  if (velocity_interface_running_) {
    for (std::size_t i = 0; i < num_joints_; ++i) {
      jointSetSpeed(hJoint_[i], joint_velocity_[i], -1, NULL);
    }
  }
  else if (position_interface_running_) {
    for (std::size_t i = 0; i < num_joints_; ++i) {
      jointPush(hJoint_[i], joint_position_command_[i]/pi*180., joint_velocity_command_[i]/pi*180., 0);
    }
  }
}

bool mrHW::prepareSwitch(
  const std::list<hardware_interface::ControllerInfo> &start_list,
  const std::list<hardware_interface::ControllerInfo> &stop_list) const {
    for (std::list<hardware_interface::ControllerInfo>::const_iterator controller_it =
      start_list.begin(); controller_it != start_list.end();
      ++controller_it) {
      if (controller_it->type == "hardware_interface::VelocityJointInterface") {
        if (velocity_interface_running_) {
          ROS_ERROR(
              "%s: An interface of that type (%s) is already running",
              controller_it->name.c_str(),
              controller_it->type.c_str());
          return false;
        }
        if (position_interface_running_) {
          bool error = true;
          for (std::list<hardware_interface::ControllerInfo>::const_iterator stop_controller_it =
              stop_list.begin();
              stop_controller_it != stop_list.end();
              ++stop_controller_it) {
            if (stop_controller_it->type
                == "hardware_interface::PositionJointInterface") {
              error = false;
              break;
            }
          }
        if (error) {
          ROS_ERROR(
              "%s (type %s) can not be run simultaneously with a PositionJointInterface",
              controller_it->name.c_str(),
              controller_it->type.c_str());
          return false;
        }
      }
    } else if (controller_it->type == "hardware_interface::PositionJointInterface") {
      if (position_interface_running_) {
        ROS_ERROR(
            "%s: An interface of that type (%s) is already running",
            controller_it->name.c_str(),
            controller_it->type.c_str());
        return false;
      }
      if (velocity_interface_running_) {
        bool error = true;
        for (std::list<hardware_interface::ControllerInfo>::const_iterator stop_controller_it =
            stop_list.begin();
            stop_controller_it != stop_list.end();
            ++stop_controller_it) {
          if (stop_controller_it->type
              == "hardware_interface::VelocityJointInterface") {
            error = false;
            break;
          }
        }
        if (error) {
          ROS_ERROR(
              "%s (type %s) can not be run simultaneously with a VelocityJointInterface",
              controller_it->name.c_str(),
              controller_it->type.c_str());
          return false;
        }
      }
    }
  }

// we can always stop a controller
  return true;
}

void mrHW::doSwitch(
  const std::list<hardware_interface::ControllerInfo>& start_list,
  const std::list<hardware_interface::ControllerInfo>& stop_list) {
  for (std::list<hardware_interface::ControllerInfo>::const_iterator controller_it =
      stop_list.begin(); controller_it != stop_list.end();
      ++controller_it) {
    if (controller_it->type
        == "hardware_interface::VelocityJointInterface") {
      velocity_interface_running_ = false;
      ROS_DEBUG("Stopping velocity interface");
    }
    if (controller_it->type
        == "hardware_interface::PositionJointInterface") {
      position_interface_running_ = false;
      ROS_DEBUG("Stopping position interface");
    }
  }
  for (std::list<hardware_interface::ControllerInfo>::const_iterator controller_it =
      start_list.begin(); controller_it != start_list.end();
      ++controller_it) {
        if (controller_it->type
        == "hardware_interface::VelocityJointInterface") {
      velocity_interface_running_ = true;
      setSpeedMode();
      ROS_DEBUG("Starting velocity interface");
        }
    if (controller_it->type
        == "hardware_interface::PositionJointInterface") {
      position_interface_running_ = true;
      setPositionMode();
      ROS_DEBUG("Starting position interface");
    }
  }

}

void mrHW::setSpeedMode()
{
  for (std::size_t i = 0; i < num_joints_; ++i) {
    jointSetMode(hJoint_[i], joint_speed, -1, NULL);
  }
}

void mrHW::setPositionMode()
{
  for (std::size_t i = 0; i < num_joints_; ++i) {
    jointSetMode(hJoint_[i], joint_cyclesync, -1, NULL);
  }
}

void mrHW::update()
{
  ros::Duration elapsed_time;
  struct timespec last_time, current_time;
  static const double BILLION = 1000000000.0;

  ros::Rate loop_rate(loop_hz_);

  clock_gettime(CLOCK_MONOTONIC, &last_time);
  while (ros::ok()) {
    elapsed_time = ros::Duration(current_time.tv_sec - last_time.tv_sec + (current_time.tv_nsec - last_time.tv_nsec)/ BILLION);

    // Input
    this->read(ros::Time::now(), elapsed_time);

    // Controllers update
    clock_gettime(CLOCK_MONOTONIC, &current_time);
    controller_manager_->update(ros::Time::now(), elapsed_time);
    last_time = current_time;

    // Output
    this->write(ros::Time::now(), elapsed_time);

    loop_rate.sleep();
  }
  for (std::size_t i = 0; i < num_devices_; ++i) {
    stopMaster(MASTER(i));
    joinMaster(MASTER(i));
  }
  ros_control_thread_->join();
}

} // namespace

int main(int argc, char **argv)
{
  bool use_sim_time = false;
  // Set up ROS.
  ros::init(argc, argv, "mr_hw");

  ROS_INFO("Hello world!");
  ros::NodeHandle nh;

  if (ros::param::get("use_sim_time", use_sim_time)) {
    ROS_DEBUG("use_sim_time is set!!");
  }

  ros_control_mr::mrHW *mra = new ros_control_mr::mrHW(nh);

  ros::spin();

  ROS_INFO_STREAM_NAMED("hardware_interface","Shutting down.");

  return 0;
}


