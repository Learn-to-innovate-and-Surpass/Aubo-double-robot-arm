# mra7a_description 

**This package is the description of the seven dof arm.**

